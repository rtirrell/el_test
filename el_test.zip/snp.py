'''
Created on Jun 10, 2010

@author: konradjk
'''

import genotype_tools

class SNP:
    '''
    SNP Class
    '''
    def __init__(self, rsid=None, chromosome=None, position=None, genotype=None, r_squared=None, nearest_SNP=None, hapmap_consensus=None):
        '''
        SNP(rsid, chromosome, position [, genotype, r_squared])
        '''
        self.rsid = rsid
        self.chromosome = chromosome
        self.position = position
        if self.chromosome is None:
            result = genotype_tools.DBUtils.get_chromosome_and_position(self.rsid)
            if result is not None:
                self.chromosome, self.position = result
        self.genotype = genotype
        self.r_squared = r_squared
        self.nearest_SNP = nearest_SNP
        self.hapmap_consensus = hapmap_consensus
        
    
    def is_homozygote(self):
        allele_1, allele_2 = list(self.genotype);
        return allele_1 == allele_2

    def risk_factor(self, risk):
        return self.genotype.count(risk)
