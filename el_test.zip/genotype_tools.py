'''
Created on Jun 10, 2010

@author: konradjk
'''

from snp import SNP
import warnings
import string

#with warnings.catch_warnings():
warnings.filterwarnings("ignore",category=DeprecationWarning)
import mysql.connector

def impute_rsid_simple(SNP_hash, query_rsid, population):
    '''
    SNP = impute_rsid(SNP_hash, rsid, population)
    '''
    
    query_SNP_in_hapmap = DBUtils.get_individuals(query_rsid, population)
    if len(query_SNP_in_hapmap) == 0:
        return None
    nearby_SNP = DBUtils.get_nearest_variable_SNP(query_rsid, SNP_hash, population)
    if nearby_SNP is not None:
        anchor_rsid, r_squared = nearby_SNP
    else:
        return None
    anchor_SNP_in_hapmap = DBUtils.get_individuals(anchor_rsid, population)
    my_anchor_SNP = SNP_hash[anchor_rsid]
    
    phase, phase_count, total = get_best_phases(query_SNP_in_hapmap, anchor_SNP_in_hapmap)
    
    genotype = phase[my_anchor_SNP.genotype[0]] + phase[my_anchor_SNP.genotype[1]]
    
    my_query_SNP = SNP(query_rsid, genotype=genotype, r_squared=r_squared, nearest_SNP=anchor_rsid, hapmap_consensus=str(phase_count) + "/" + str(total))
    return my_query_SNP

def get_best_phases(query_SNP_hash, anchor_SNP_hash):
    anchor_SNP_options = []
    query_SNP_options = []
    for anchor_allele in anchor_SNP_hash.values():
        anchor_SNP_options.append(anchor_allele)
    for query_allele in query_SNP_hash.values():
        query_SNP_options.append(query_allele)
    anchor_SNP_option_1, anchor_SNP_option_2 = list(set(anchor_SNP_options))
    query_SNP_option_1, query_SNP_option_2 = list(set(query_SNP_options))
    phase_1 = 0
    phase_2 = 0
    for individual, anchor_allele in anchor_SNP_hash.items():
        query_allele = query_SNP_hash[individual]
        if anchor_allele == anchor_SNP_option_1:
            if query_allele == query_SNP_option_1:
                phase_1 += 1
            else:
                phase_2 += 1
        else:
            if query_allele == query_SNP_option_2:
                phase_1 += 1
            else:
                phase_2 += 1
    phase_output = {}
    if phase_1 >= phase_2:
        phase_output[anchor_SNP_option_1] = query_SNP_option_1
        phase_output[anchor_SNP_option_2] = query_SNP_option_2
        return phase_output, phase_1, phase_1 + phase_2
    else:
        phase_output[anchor_SNP_option_1] = query_SNP_option_2
        phase_output[anchor_SNP_option_2] = query_SNP_option_1
        return phase_output, phase_2, phase_1 + phase_2

def convert_population(input_population):
    if input_population.upper().find('E') == 0:
        print 'Analyzing for European ancestry (CEU; Utah Residents with Ancestry from Northern and Western Europe)'
        return 'CEU'
    elif input_population.upper().find('C') == 0:
        print 'Analyzing for Chinese ancestry (CHB; Han Chinese in Beijing, China)'
        return 'CHB'
    elif input_population.upper().find('J') == 0:
        print 'Analyzing for Japanese ancestry (JPT; Japanese in Tokyo, Japan)'
        return 'JPT'
    elif input_population.upper().find('A') == 0:
        print 'Analyzing for African ancestry (YRI; Yoruba in Ibadan, Nigeria)'
        return 'YRI'
    else:
        print 'Did not recognize population: %s' % input_population
        print 'Options are E(uropean), C(hinese), J(apanese), A(frican)'
        return None
    
def convert_population_full(input_population):
    if input_population.upper() == 'CEU':
        return 'Caucasian'
    if input_population.upper() == 'YRI':
        return 'African'
    if input_population.upper() == 'CHB':
        return 'Chinese'
    if input_population.upper() == 'JPT':
        return 'Japanese'

def convert_gender(input_gender):
    if input_gender.upper().find('F') == 0:
        print 'Analyzing for Female'
        return 'female'
    elif input_gender.upper().find('M') == 0:
        print 'Analyzing for Male'
        return 'Male'
    else:
        print 'Did not recognize gender: %s' % input_gender
        print 'Options are F(emale), M(ale)'
        return None

def get_diabetes_risk(gender, population):
    if gender == 'Male':
        if population == 'CEU':
            return 0.237
        elif population == 'YRI':
            return 0.233
        elif population == 'CHB' or population == 'JPT':
            return 0.2
    else:
        if population == 'CEU':
            return 0.182
        elif population == 'YRI':
            return 0.233
        elif population == 'CHB' or population == 'JPT':
            return 0.2

def odds(probability):
    return float(probability)/float(1-probability)

def probability(odds):
    return odds/(1+odds)

def odds_ratio(high, low):
    '''
    OR = odds_ratio(high, low)
    
    Helper function for calculating odds ratio given probabilities
    '''
    return odds(high)/odds(low)

class DBUtils(object):
    '''
    Utility functions for databases
    '''
    database = mysql.connector.Connect(host='marlowe', user='gene210-user', passwd='genomics', buffered=True)
    db = database.cursor()
    
    @classmethod
    def get_risk_snp_info(cls, disease, rsid, full_population):
        query = 'SELECT risk_allele, total_sample FROM diseases.diabetes_snps WHERE dbsnp=%s AND population_simple="%s"' % (rsid.lstrip('rs'), full_population)
        #query = 'SELECT comparison, o_r, total_sample FROM diseases.disease_snp WHERE broad_phenotype="%s" AND dbsnp=%s' % (disease, rsid.lstrip('rs'))
        cls.db.execute(query)
        query_array = cls.db.fetchone()
        if query_array is not None:
            risk_allele = query_array[0]
            total_sample = int(query_array[1])
            return risk_allele, total_sample
        return None, None
    
    @classmethod
    def get_study_genotype_frequnecies(cls, disease, rsid, population_full):
        query = 'SELECT Genotype_1, freq_cases_G1, freq_controls_G1, Genotype_2, freq_cases_G2, freq_controls_G2, Genotype_3, freq_cases_G3, freq_controls_G3 FROM diseases.diabetes_snps WHERE dbsnp=%s AND population_simple="%s"' % (rsid.lstrip('rs'), population_full)
        #query = 'SELECT comparison, o_r, total_sample FROM diseases.disease_snp WHERE broad_phenotype="%s" AND dbsnp=%s' % (disease, rsid.lstrip('rs'))
        cls.db.execute(query)
        query_array = cls.db.fetchone()
        if query_array is not None:
            cases = {}
            controls = {}
            #print query_array[0]
            cases[str(query_array[0])] = float(query_array[1])
            controls[str(query_array[0])] = float(query_array[2])
            cases[str(query_array[3])] = float(query_array[4])
            controls[str(query_array[3])] = float(query_array[5])
            cases[str(query_array[6])] = float(query_array[7])
            controls[str(query_array[6])] = float(query_array[8])
            return cases, controls
        return None, None

    @classmethod
    def get_disease_prevalence(cls, disease, population, gender):
        population = 'caucasian' #we lied.
        query = 'SELECT probability FROM diseases.pretest_%s_%s WHERE broad_phenotype="%s"' % (population, gender, disease)
        cls.db.execute(query)
        prevalence = cls.db.fetchone()
        return prevalence
    
    @classmethod
    def get_gene(cls, rsid):
        query = 'SELECT symbol FROM snp_annotations.snp_gene where rsid="%s"' % (rsid)
        #print query
        cls.db.execute(query)
        gene_symbol = cls.db.fetchone()
        if gene_symbol is not None:
            return gene_symbol[0]
        else:
            return None
    @classmethod
    def get_genotype_frequencies(cls, rsid, population):
        query = '''
            SELECT homozygous_genotype_reference_allele, freq_homozygous_genotype_ref_allele, 
            heterozygous_genotype, freq_heterozygous_genotype,
            homozygous_genotype_other_allele, freq_homozygous_genotype_other_allele
            FROM genotype_frequencies.genotype_freqs_%s where rs_id="%s" 
        ''' % (population, rsid)
        cls.db.execute(query)
        query_array = cls.db.fetchone()
        if query_array is not None:
            genotype_frequency_array = {}
            #print query_array[0]
            genotype_frequency_array[str(query_array[0]).replace('/', '')] = float(query_array[1])
            genotype_frequency_array[str(query_array[2]).replace('/', '')] = float(query_array[3])
            genotype_frequency_array[str(query_array[4]).replace('/', '')] = float(query_array[5])
            return genotype_frequency_array
        else:
            return None
    @classmethod
    def get_allele_frequencies(cls, rsid, population):
        cls.db.execute('''
            SELECT reference_allele, frequency_of_ref_allele, 
            other_allele, frequency_of_other_allele
            FROM allele_frequencies.allele_freqs_%s where rs_id="%s" 
        ''' % (population, rsid))
        query_array = cls.db.fetchone()
        if query_array is not None:
            genotype_frequency_array = {}
            genotype_frequency_array[str(query_array[0])] = float(query_array[1])
            genotype_frequency_array[str(query_array[2])] = float(query_array[3])
            return genotype_frequency_array
        else:
            return None
    
    @classmethod
    def get_pubmed_ids(cls, rsid):
        cls.db.execute('''
            SELECT pubmed_id FROM snp_annotations.snp_pubmed
            WHERE snp_id="%s"
        ''' % (rsid.lstrip('rs')))
        return cls.db.fetchall()
    
    @classmethod
    def get_genotype_frequency(cls, genotype, rsid, population):
        all_frequencies = cls.get_genotype_frequencies(rsid, population)
        if all_frequencies is not None:
            return all_frequencies[genotype]
        else:
            return None
    @classmethod
    def get_risk_genotype_frequencies(cls, rsid, risk_allele, population):
        '''
        population_high_risk, population_het, population_low_risk = get_risk_genotype_frequencies(rsid, risk_allele)
        '''
        all_genotypes = cls.get_genotype_frequencies(rsid, population)
        if all_genotypes is not None:
            for genotype, frequency in all_genotypes.items():
                #print '%s\t%s' % (genotype, frequency)
                if genotype.count(risk_allele) == 2:
                    population_high_risk = float(frequency)
                elif genotype.count(risk_allele) == 1:
                    population_het = float(frequency)
                else:
                    population_low_risk = float(frequency)
            return (population_high_risk, population_het, population_low_risk)
        else:
            return None

    @classmethod
    def get_nearest_variable_SNP(cls, rsid, SNP_hash, population):
        query = '''
            SELECT dbsnp1, dbsnp2, R_square FROM haplotypes.LD_%s
            where dbsnp1=%s or dbsnp2=%s
            order by R_square desc;
        ''' % (population, rsid.lstrip('rs'), rsid.lstrip('rs'))
        #print query
        cls.db.execute(query)
        r_squared_threshold = 0.3
        for dbsnp1, dbsnp2, R_square in cls.db.fetchall():
            #print dbsnp1, dbsnp2, R_square
            if rsid.lstrip('rs') == str(dbsnp1):
                test_rsid = 'rs' + str(dbsnp2)
            else:
                test_rsid = 'rs' + str(dbsnp1)
            #print test_rsid
            if R_square < r_squared_threshold:
                return None
            if test_rsid in SNP_hash:
                return test_rsid, R_square
        return None
    
    @classmethod
    def is_variable_in_population(cls, test_rsid, population):
        test_SNP_in_hapmap = cls.get_individuals(test_rsid, population)
        last_allele = ''
        for allele in test_SNP_in_hapmap.values():
            if last_allele == '':
                last_allele = allele
            elif allele != last_allele:
                return True
        return False
    
    @classmethod
    def get_individuals(cls, rsid, population):
        query = '''
            SELECT individual_allele, allele FROM hapmap_individuals.phased_individual_%s
            where rsid="%s"
        ''' % (population, rsid)
        #print query
        cls.db.execute(query)
        individuals = {}
        for individual, allele in cls.db.fetchall():
            individuals[individual] = allele
        return individuals
    
    @classmethod
    def get_chromosome_and_position(cls, rsid):
        query = '''
            SELECT chr, pos FROM snp_annotations.snp_location WHERE snp_id="%s"
        ''' % rsid.lstrip('rs')
        #print query
        cls.db.execute(query)
        return cls.db.fetchone()
    
class FileUtils(object):
    
    @classmethod
    def read_genotype_file(cls, filename):
        '''
        SNP_hash = read_genotype_file(filename)
        
        Reads genotype file from 23andMe raw file
        Returns hash of SNPs, indexed by rsid
        '''
        try:
            f = open(filename, 'r')
        except IOError:
            return {}
        SNP_hash = {}
        for line in f:
            if line.strip()[0] != '#':
                if line.strip()[-1] == '-':
                    continue
                rsid, chromosome, position, genotype = line.split()
                if chromosome == 'MT':
                    continue
                if genotype.find('D') == -1 and genotype.find('I') == -1:
                    x = SNP(rsid, chromosome, position, genotype)
                    SNP_hash[rsid] = x
        f.close()
        #print '%s SNPs read' % len(SNP_hash)
        return SNP_hash
    
    @classmethod
    def write_genotype_file(cls, SNPs, filename):
        '''
        write_genotype_file(SNPs, filename)
        
        Write genotype file from hash of SNPs, output similar to 23andMe raw file
        '''
        try:
            f = open(filename, 'w')
        except IOError:
            print 'Writing to %s failed for some reason' % filename
            return None
        for SNP in SNPs.values():
            f.write('\t'.join([SNP.rsid, str(SNP.chromosome), str(SNP.position), SNP.genotype]))
            if SNP.confidence is not None:
                f.write('\t' + str(SNP.confidence))
            f.write('\n')
        f.close()