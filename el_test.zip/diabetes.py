'''
Diabetes Risk Utility
    Usage: python diabetes.py genotype.txt

    Created on Jul 9, 2010    
    @author: konradjk
'''

import genotype_tools
import sys
from snp import SNP
from risk_snp import Risk_SNP
import subprocess
import time
import os

if len(sys.argv) < 2:
    print "Please enter genotype file name"
    print __doc__
    sys.exit()

filename = sys.argv[1]
my_snps = genotype_tools.FileUtils.read_genotype_file(filename)
rsid_list = sys.argv[2]

if len(my_snps) == 0:
    print "Cannot read file: %s" % filename
    print __doc__
    sys.exit()

delete = False
_, filename_nopath = os.path.split(filename)
out_file_name = 'diabetes.' + filename_nopath.rstrip('.txt') +'.html'

raw_population = raw_input('Population ([E]uropean, [C]hinese, [J]apanese): ')
population = genotype_tools.convert_population(raw_population)
full_population = genotype_tools.convert_population_full(population)
if population is None:
    sys.exit()

raw_gender = raw_input('Population ([F]emale, [M]ale): ')
gender = genotype_tools.convert_gender(raw_gender)
if gender is None:
    sys.exit()

my_odds_ratio = 1
pre_test_prob = genotype_tools.get_diabetes_risk(gender, population)
pre_test_odds = genotype_tools.odds(pre_test_prob)
post_test_likelihood = pre_test_odds
post_test_odds = pre_test_odds

diabetes_SNPs = []
try:
    file = open(rsid_list, 'r')
except IOError:
    print 'Could not find file %s' % rsid_list
    sys.exit()
for line in file:
    rsid = line.strip()
    risk = Risk_SNP('Type 2 Diabetes', rsid, full_population)
    diabetes_SNPs.append(risk)
    
diabetes_SNPs.sort(key=lambda x: x.total_sample, reverse=True)

out_file = open(out_file_name, 'w')
out_file.write('<html><body><h3>Diabetes Risk for Personal Genotype</h3>')
out_file.write('''
    Population given was: %s<br>
    Gender given was: %s<br><br>
    Pre-test probability for %s %s is: %.3f%% (Odds = %.3f)<br><br>
''' % (population, gender, full_population, gender, 100*pre_test_prob, pre_test_odds))
out_file.write('''
<table border="1">
<tr>
<th>RSID</th>
<th>Genotype</th>
<th>Study Size</th>
<th>Odds Ratio*</th>
<th>Post-test odds (OR*)</th>
<th>Post-test probability (OR*)</th>
<th>Likelihood Ratio</th>
<th>Post-test odds (LR)</th>
<th>Post-test probability (LR)</th>
</tr>
''')
out_file.write('<tr><td><b>Pre-test:<td></td><td></td><td></td><td><b>%.3f</td><td><b>%.1f%%</td><td></td><td><b>%.3f</td><td><b>%.1f%%</td></tr>' % (pre_test_odds, 100*pre_test_prob, pre_test_odds, 100*pre_test_prob))
snp_names = ''
snp_count = ''
pre_test_string = ''
lr_string = ''
or_string = ''
count = 0
pre_t_s = pre_test_prob*100
min = pre_t_s
max = pre_t_s
for risk in diabetes_SNPs:
    count += 1
    rsid = risk.rsid
    #print rsid
    snp_names += '|%s' % rsid
    snp_count += ',%s' % count
    pre_test_string += ',%s' % pre_t_s
    out_file.write('<tr><td>%s</td><td>%s</td><td>%s</td>' % (rsid, my_snps[rsid].genotype, risk.total_sample))
    adjusted_odds_ratio = risk.or_star(my_snps[rsid].genotype, gender, population)
    likelihood_ratio = risk.likelihood_ratio(my_snps[rsid].genotype, population)
    if adjusted_odds_ratio is not None:
        post_test_odds *= adjusted_odds_ratio
        out_file.write('<td>%.3f</td><td>%.3f</td><td>%.1f%%</td>' % (adjusted_odds_ratio, post_test_odds, 100*genotype_tools.probability(post_test_odds)))
    else:
        out_file.write('<td>Not found</td><td>-</td><td>-</td>')
    or_s = 100*genotype_tools.probability(post_test_odds)
    or_string += ',%s' % or_s
    
    if likelihood_ratio is not None:
        post_test_likelihood *= likelihood_ratio
        out_file.write('<td>%.3f</td><td>%.3f</td><td>%.1f%%</td>' % (likelihood_ratio, post_test_likelihood, 100*genotype_tools.probability(post_test_likelihood)))
    else:
        out_file.write('<td>Not found</td><td>-</td><td>-</td>')
    lr_s = 100*genotype_tools.probability(post_test_likelihood)
    lr_string += ',%s' % lr_s
    out_file.write('</tr>')
    if or_s < min:
        min = or_s
    if lr_s < min:
        min = lr_s
    if or_s > max:
        max = or_s
    if lr_s > max:
        max = lr_s
        
out_file.write('<tr><td><b>Total:<td></td><td></td><td></td><td><b>%.3f</td><td><b>%.1f%%</td><td></td><td><b>%.3f</td><td><b>%.1f%%</td></tr>' % (post_test_odds, 100*genotype_tools.probability(post_test_odds), post_test_likelihood, 100*genotype_tools.probability(post_test_likelihood)))
out_file.write('</table><br>')
min -= 0.5
max += 0.5
axis = '%s,%s' % (min, max)
google_start = '<img src="http://chart.apis.google.com/chart'
google_snps = '?chxl=0:%s' % snp_names
google_label_pos = '&chxp=0%s' % snp_count
google_xrange = '&chxr=0,0,%s|1,%s' % (count, axis)
google_type_size_type_lines = '&chxt=x,y&chs=640x240&cht=lxy&chco=3072F3,FF0000,FF9900'
google_scales = '&chds=0,%s,%s,0,%s,%s,0,%s,%s' % (count, axis, count, axis, count, axis)
google_datapoints = '&chd=t:-1|%s%s|-1|%s%s|-1|%s%s' % (pre_t_s, lr_string, pre_t_s, or_string, pre_t_s, pre_test_string)
#google_datapoints = '&chd=t:-1|23.7,24.7,24.9,23.5,24.6|-1|23.7,22.7,22.9,23.5,22.6|-1|23.7,23.7,23.7,23.7,23.7,23.7'
google_lines_names = '&chdl=Likelihood+Ratio|Odds+Ratio*|Average+Risk'
something = '&chdlp=b'
google_line_styles = '&chls=1|1|1'
google_margins = '&chma=5,5,5,25'
google_title = '&chtt=Your+Diabetes+Risk'
something_else = '&chts=676767,20">'
google_string = google_start + google_snps + google_label_pos + google_xrange + google_type_size_type_lines + google_scales + google_datapoints + google_lines_names + something + google_line_styles + google_margins + google_title + something_else
#print google_string
out_file.write(google_string)
out_file.write('</body></html>')
out_file.close()

subprocess.Popen(('open',out_file_name)).wait()
if delete == True:
    time.sleep(5)
    subprocess.Popen(('rm',out_file_name))
        
